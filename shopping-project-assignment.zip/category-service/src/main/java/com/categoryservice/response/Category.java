package com.categoryservice.response;

public class Category {
    private String name;
  
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
    
    // getters and setters omitted for brevity
    
}